from django.apps import AppConfig


class FileuploadAppConfig(AppConfig):
    name = 'fileupload_app'
